#include <iostream>
#include "maps.hh"

int main()
{
	print_frequencies(get_frequencies());
	return 0;
}
