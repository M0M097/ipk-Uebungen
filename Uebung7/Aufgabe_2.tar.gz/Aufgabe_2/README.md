# How to Build the Solution

You can build the solution with the follwing steps:

- Create a subdirectory: `mkdir build`

- Go to the subdirectory: `cd build`

- Call cmake: `cmake ..`

- Call make: `make`

In order to run the tests call `ctest` in the `build` directory.
